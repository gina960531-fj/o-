# -*- coding: utf-8 -*-
"""
檢查「雲端資料同步」的設定對不對，一步一步告訴你卡在哪裡。
用法：python check_sync.py
金鑰用隱藏輸入（貼上時畫面不會顯示任何字），不會被印出來，也不會存到任何地方。
測試會在資料專案裡建立再刪除一個叫 data/_sync_test.txt 的小檔案。
"""
import getpass
import os
import sys

import persist

token = (os.environ.get("GITHUB_DATA_TOKEN") or getpass.getpass("貼上金鑰（貼上時畫面不會顯示任何字，貼完按 Enter）：")).strip()
repo = (os.environ.get("GITHUB_DATA_REPO") or input("資料專案（格式：帳號/專案名，例如 gina960531-fj/o-data）：")).strip().strip("/")

if not token.startswith(("github_pat_", "ghp_")):
    print("⚠️ 這串金鑰不是 github_pat_ 或 ghp_ 開頭，可能複製錯了（要複製 GitHub 產生金鑰那一頁顯示的完整字串）。")
if "/" not in repo or " " in repo:
    print("❌ 專案格式不對，應該長得像「帳號/o-data」（中間一個斜線，沒有空格）。")
    sys.exit(1)

store = persist.GitHubStore(token, repo)
step = 0


def run(title, fn):
    global step
    step += 1
    try:
        res = fn()
        print(f"✅ 第 {step} 步：{title}" + (f"（{res}）" if res else ""))
        return True
    except Exception as e:
        print(f"❌ 第 {step} 步：{title}\n   {str(e)[:400]}")
        return False


def who():
    r = store.s.get("https://api.github.com/user", timeout=20)
    if r.status_code == 401:
        raise RuntimeError("金鑰無效或已過期（401）。請到 GitHub 重新產生金鑰。")
    if r.status_code == 200:
        return "登入帳號：" + r.json().get("login", "?")
    return f"GitHub 回應 {r.status_code}（細粒度金鑰有時不能讀帳號資料，這不一定是問題）"


def test_write():
    path = "data/_sync_test.txt"
    existing = store.tree().get(path)
    store.write(path, b"sync test", sha=existing, message="sync self-test")
    sha = store.tree().get(path)
    if not sha:
        raise RuntimeError("寫入後讀不到檔案")
    store.delete(path, sha, message="remove sync self-test")
    return "已建立並刪除測試檔"


ok = run("金鑰是否有效", who)
ok = ok and run(f"找得到專案「{repo}」與分支 main", store.verify)
ok = ok and run("讀取資料專案", lambda: f"目前有 {len(store.tree())} 個資料檔")
ok = ok and run("寫入權限（Contents: Read and write）", test_write)
print()
if ok:
    print("🎉 全部通過。把同樣的兩個值放進 Streamlit 的 Secrets：")
    print(f'   GITHUB_DATA_TOKEN = "（你的金鑰）"\n   GITHUB_DATA_REPO = "{repo}"')
else:
    print("上面第一個 ❌ 就是問題所在，照它的說明修正後再執行一次。常見原因：")
    print("  1. 專案名稱打錯（要和 GitHub 網址 github.com/帳號/專案名 完全一致）")
    print("  2. 建立金鑰時，Repository access 沒有選到這個專案")
    print("  3. 金鑰的 Contents 權限不是 Read and write")
    print("  4. 專案是空的：到專案首頁用 Add file 新增一個檔案（或建立專案時勾 Add a README file）")
    sys.exit(1)
